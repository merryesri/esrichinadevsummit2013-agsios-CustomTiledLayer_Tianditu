//
//  TianDiTuWMTSLayerInfo.m
//  CustomTiledLayerV10.11
//
//  Created by EsriChina_Mobile_MaY on 13-3-28.
//
//

#import "TianDiTuWMTSLayerInfo.h"

@implementation TianDiTuWMTSLayerInfo

@synthesize url = _url;
@synthesize layerName = _layerName;
@synthesize minZoomLevel = _minZoomLevel;
@synthesize maxZoomLevel = _maxZoomLevel;
@synthesize xMin = _xMin;
@synthesize yMin = _yMin;
@synthesize xMax = _xMax;
@synthesize yMax = _yMax;
@synthesize tileWidth = _tileWidth;
@synthesize tileHeight = _tileHeight;
@synthesize lods = _lods;
@synthesize dpi = _dpi;
@synthesize srid = _srid;
@synthesize origin = _origin;
@synthesize tileMatrixSet = _tileMatrixSet;

@end
